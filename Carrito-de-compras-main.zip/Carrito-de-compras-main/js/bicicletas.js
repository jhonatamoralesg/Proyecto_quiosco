/* Esta lista podría ser reemplazada por la respuesta de un backend */
const bicicletas = [
  {
    id:1,
    nombre: "Veloziraptor",
    precio: 111111,
  },
  {
    id:2,
    nombre: "Biciclón",
    precio: 222222,
  },
  {
    id:3,
    nombre: "CicloTravesura",
    precio: 333333,
  },
  {
    id:4,
    nombre: "Pedalástica",
    precio: 444444,
  },
  {
    id:5,
    nombre: "RuedaFrenesí",
    precio: 555555,
  },
  {
    id:6,
    nombre: "CicloLoco",
    precio: 666666,
  }
]